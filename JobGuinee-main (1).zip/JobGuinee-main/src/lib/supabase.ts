import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type UserRole = 'candidate' | 'recruiter' | 'admin' | 'trainer';

export type Profile = {
  id: string;
  user_type: UserRole;
  full_name: string;
  email: string;
  phone?: string;
  avatar_url?: string;
  birth_date?: string;
  gender?: string;
  address?: string;
  region?: string;
  created_at: string;
  updated_at: string;
};

export type CandidateProfile = {
  id: string;
  profile_id: string;
  title?: string;
  bio?: string;
  cv_url?: string;
  skills: string[];
  experience_years: number;
  education_level?: string;
  education?: any;
  work_experience?: any;
  location?: string;
  availability: string;
  desired_position?: string;
  desired_salary_min?: number;
  desired_salary_max?: number;
  languages?: string[];
  certifications?: any;
  preferred_contract_type?: string;
  mobility?: string;
  is_verified?: boolean;
  visibility?: string;
  last_active_at?: string;
  nationality?: string;
};

export type Company = {
  id: string;
  user_id: string;
  company_name: string;
  logo_url?: string;
  description?: string;
  sector?: string;
  website?: string;
  location?: string;
  size?: string;
};

export type Job = {
  id: string;
  company_id: string;
  title: string;
  description: string;
  requirements?: string;
  responsibilities?: string;
  benefits?: string;
  location?: string;
  contract_type?: string;
  sector?: string;
  experience_level?: string;
  education_level?: string;
  salary_min?: number;
  salary_max?: number;
  status: 'draft' | 'pending' | 'published' | 'expired' | 'closed';
  deadline?: string;
  is_featured: boolean;
  is_urgent: boolean;
  views_count: number;
  applications_count: number;
  nationality_required?: string;
  languages?: string[];
  keywords?: string[];
  created_at: string;
  updated_at: string;
  companies?: Company;
};

export type Application = {
  id: string;
  job_id: string;
  candidate_id: string;
  cv_url?: string;
  cover_letter?: string;
  status: 'pending' | 'reviewed' | 'shortlisted' | 'rejected' | 'accepted';
  ai_match_score?: number;
  recruiter_notes?: string;
  created_at: string;
  updated_at: string;
  jobs?: Job;
  profiles?: Profile;
};

export type Formation = {
  id: string;
  title: string;
  description?: string;
  price: number;
  duration?: string;
  instructor?: string;
  category?: string;
  thumbnail_url?: string;
  status: string;
  created_at: string;
  updated_at: string;
};

export type TrainerProfile = {
  id: string;
  profile_id: string;
  user_id: string;
  organization_name?: string;
  organization_type: 'individual' | 'company' | 'institute';
  bio?: string;
  specializations: string[];
  certifications?: any;
  experience_years: number;
  website?: string;
  linkedin_url?: string;
  hourly_rate?: number;
  is_verified: boolean;
  rating: number;
  total_students: number;
  individual_phone?: string;
  individual_address?: string;
  individual_skills?: string[];
  company_name?: string;
  company_registration_number?: string;
  company_contact_person?: string;
  company_contact_position?: string;
  company_email?: string;
  company_phone?: string;
  company_address?: string;
  company_city?: string;
  company_country?: string;
  company_sector?: string;
  company_size?: string;
  company_description?: string;
  institute_name?: string;
  institute_registration_number?: string;
  institute_contact_person?: string;
  institute_contact_position?: string;
  institute_email?: string;
  institute_phone?: string;
  institute_address?: string;
  institute_city?: string;
  institute_country?: string;
  institute_type?: string;
  institute_accreditation?: any;
  institute_description?: string;
  created_at: string;
  updated_at: string;
};
